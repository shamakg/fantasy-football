# This project contains several different models to predict the fantasy points of the top football players in a fantasy league in a given week.
# Data.py and Merge.py exist solely to take data from the ESPN API, which contains data for all football players. It gets data from a dummy league without any participants, where all players are free agents.
